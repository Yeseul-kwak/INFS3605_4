// Optional: hard-code your Supabase project here (the anon key is meant to be public).
// You can leave these empty and instead set SUPABASE_URL and SUPABASE_ANON_KEY as
// environment variables on Vercel (see README), or type them into the setup screen.
window.BREWROSTER_CONFIG = { SUPABASE_URL: '', SUPABASE_ANON_KEY: '' };
