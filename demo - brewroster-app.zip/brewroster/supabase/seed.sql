-- Optional: load the sample cafe (Little Wren Coffee) from the SQL editor.
-- The app can also do this for you with the "Load sample data" button on first sign-in.
-- Dates are relative to today, so the sample is always current.
select public.seed_demo(false);
